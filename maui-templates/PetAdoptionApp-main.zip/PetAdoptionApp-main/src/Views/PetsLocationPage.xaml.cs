namespace PetAdoptionApp.Views;

public partial class PetsLocationPage : ContentPage
{
	public PetsLocationPage()
	{
		InitializeComponent();
	}
}