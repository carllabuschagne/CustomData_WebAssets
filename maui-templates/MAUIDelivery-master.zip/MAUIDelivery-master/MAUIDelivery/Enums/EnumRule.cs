﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDelivery.Enums
{
     public enum EnumRule
     {
          None,
          Min0_Max1,
          Min1_Max1,
          Max
     }
}
