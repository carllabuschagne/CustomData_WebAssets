Thanks for downloading this template!

Template Name: Maxim
Template URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
