# MAUI Finance
UI built in .NET MAUI, based on [a Dribbble design](https://dribbble.com/shots/14210557-Finance-Mobile-Application-UX-UI-Design).

![Screenshot](https://user-images.githubusercontent.com/20908430/198023603-075244e8-6408-4d02-98bf-e42bb8325eaa.png)

https://user-images.githubusercontent.com/20908430/198023619-8807aaf5-ca0c-49cf-a7ce-e0043a630ea5.mp4
