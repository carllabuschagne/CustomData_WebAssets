﻿namespace MauiFinance.Models;

public class OverviewItem
{
    public string IconSource { get; set; }

    public string Title { get; set; }

    public string Details { get; set; }

    public int Amount { get; set; }
}