﻿using MauiFinance.Views;

namespace MauiFinance;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();
		
		MainPage = new MainPage();
	}
}