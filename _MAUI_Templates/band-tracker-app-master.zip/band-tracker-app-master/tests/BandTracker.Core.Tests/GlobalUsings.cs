global using Xunit;
global using FluentAssertions;
global using BandTracker.Core.Bands;
global using BandTracker.Core.Users;
global using BandTracker.Core.Utils;