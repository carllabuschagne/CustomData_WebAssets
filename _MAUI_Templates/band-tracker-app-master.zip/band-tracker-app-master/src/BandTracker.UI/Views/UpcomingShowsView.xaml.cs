namespace BandTracker.UI.Views;

public partial class UpcomingShowsView
{
    public UpcomingShowsView(UpcomingShowsViewModel vm) : base(vm)
	{
		InitializeComponent();
    }
}
