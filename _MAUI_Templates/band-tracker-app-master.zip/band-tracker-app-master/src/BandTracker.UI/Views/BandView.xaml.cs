namespace BandTracker.UI.Views;

public partial class BandView
{
	public BandView(BandViewModel vm) : base(vm)
	{
		InitializeComponent();
    }
}