namespace BandTracker.UI.Views;

public partial class ReleaseView
{
    public ReleaseView(ReleaseViewModel vm) : base(vm)
    {
        InitializeComponent();
    }
}
