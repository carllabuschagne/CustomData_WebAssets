namespace BandTracker.UI.Views;

public partial class RecentReleasesView
{
    public RecentReleasesView(RecentReleasesViewModel vm) : base(vm)
	{
		InitializeComponent();
    }
}
