namespace BandTracker.UI.Views;

public partial class DashboardView
{
	public DashboardView(DashboardViewModel vm) : base(vm)
	{
		InitializeComponent();
	}
}