﻿namespace BandTracker.Core.Html;

public interface IHtmlUtilityService
{
    string GetFullHtmlPage(string content);
}