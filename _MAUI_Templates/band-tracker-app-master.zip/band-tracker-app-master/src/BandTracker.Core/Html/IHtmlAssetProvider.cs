﻿namespace BandTracker.Core.Html;

public interface IHtmlAssetProvider
{
    string GetAssetsPath();
}
