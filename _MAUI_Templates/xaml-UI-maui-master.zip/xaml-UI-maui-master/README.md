# ManagementSystem

screenshot

https://github.com/ahror1997/xaml-UI-maui/blob/master/Images/screen1.jpg?raw=true
