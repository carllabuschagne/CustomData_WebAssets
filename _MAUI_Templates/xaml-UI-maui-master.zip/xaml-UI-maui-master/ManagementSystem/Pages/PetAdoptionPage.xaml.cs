namespace ManagementSystem.Pages;

public partial class PetAdoptionPage : ContentPage
{
	public PetAdoptionPage()
	{
		InitializeComponent();
	}
}