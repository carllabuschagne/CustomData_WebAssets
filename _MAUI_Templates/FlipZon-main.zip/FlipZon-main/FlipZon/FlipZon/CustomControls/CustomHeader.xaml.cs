﻿namespace FlipZon.CustomControls;

public partial class CustomHeader : ContentView
{
   
    public CustomHeader()
    {
        InitializeComponent();
    }

    void ImageButton_Clicked(System.Object sender, System.EventArgs e)
    {
    }
}

