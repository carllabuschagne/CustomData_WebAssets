﻿global using System.Text;
global using Newtonsoft.Json;
global using System.Collections.ObjectModel;
global using FlipZon.Models;
global using FlipZon.Service;
global using FlipZon.Utilities;
global using FlipZon.Views;
global using MauiSampleTest.Service;
global using MauiSampleTest.ViewModels;
global using FlipZon.Service.Interfaces;
global using System.Net.Http.Headers;
global using SQLite;
global using FlipZon.Resources.Localization;
global using Mopups.Interfaces;
global using Controls.UserDialogs.Maui;
global using FlipZon.ViewModels;

