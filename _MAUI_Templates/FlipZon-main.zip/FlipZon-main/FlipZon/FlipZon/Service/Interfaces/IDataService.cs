﻿namespace MauiSampleTest.Service
{
    public interface IDataService
    {
        bool ClearDetailPageStack { get; set; }
    }
}

