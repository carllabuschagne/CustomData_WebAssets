﻿using System;
namespace FlipZon.CustomRenders
{
    public class CustomEntry:Entry
    {
       
    }
}

