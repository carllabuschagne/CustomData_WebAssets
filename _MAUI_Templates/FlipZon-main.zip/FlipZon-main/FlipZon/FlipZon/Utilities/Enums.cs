﻿using System;
namespace FlipZon.Utilities
{
    public enum MessageType
    {
        Postive=1,
        Negative=2,
    }
}

