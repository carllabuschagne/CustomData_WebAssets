﻿namespace FlipZon.Views;

public partial class SearchScreen : ContentPage
{
    public SearchScreen()
    {
        InitializeComponent();
    }
}

