﻿namespace FlipZon.Views.ContentViews;

public partial class NoInternetAccessScreen : ContentView
{
    public NoInternetAccessScreen()
    {
        InitializeComponent();
    }
}

