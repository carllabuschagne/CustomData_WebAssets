﻿namespace FlipZon.Views;

public partial class ProductsScreen : ContentPage
{
    public ProductsScreen()
    {
        InitializeComponent();
    }
}

