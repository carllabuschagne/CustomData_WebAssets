﻿namespace FlipZon.Views;

public partial class HomeScreen : ContentPage
{
    public HomeScreen()
    {
        InitializeComponent();
    }
}

