﻿namespace FlipZon.Views;

public partial class AddAddressScreen : ContentPage
{
    public AddAddressScreen()
    {
        InitializeComponent();
    }
}

