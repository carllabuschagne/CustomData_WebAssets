﻿namespace FlipZon.Views;

public partial class OrderConfirmationScreen : ContentPage
{
    public OrderConfirmationScreen()
    {
        InitializeComponent();
    }
}

