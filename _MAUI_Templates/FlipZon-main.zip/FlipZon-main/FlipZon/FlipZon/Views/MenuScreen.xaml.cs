﻿namespace FlipZon.Views;


public partial class MenuScreen : ContentPage
{
   
    public MenuScreen()
    {
        InitializeComponent();
    }

   
}

