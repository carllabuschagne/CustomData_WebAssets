﻿namespace FlipZon.Views;

public partial class SignupScreen : ContentPage
{
    public SignupScreen()
    {
        InitializeComponent();
    }
}

