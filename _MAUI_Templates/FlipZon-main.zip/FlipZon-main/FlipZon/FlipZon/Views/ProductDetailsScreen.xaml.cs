﻿namespace FlipZon.Views;

public partial class ProductDetailsScreen : ContentPage
{
    public ProductDetailsScreen()
    {
        InitializeComponent();
    }
}

