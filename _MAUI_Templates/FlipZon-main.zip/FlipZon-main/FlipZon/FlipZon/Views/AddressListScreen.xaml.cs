﻿namespace FlipZon.Views;

public partial class AddressListScreen : ContentPage
{
    public AddressListScreen()
    {
        InitializeComponent();
    }
}

