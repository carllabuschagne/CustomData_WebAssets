﻿using Microsoft.Maui.Handlers;

namespace FlipZon.Platforms.iOS.Handlers
{
    public class CustomEntryHandler : EntryHandler
    {
        //protected override void ConnectHandler(AppCompatEditText platformView)
        //{
        //    base.ConnectHandler(platformView);
        //    if (platformView != null)
        //    {

        //    }
        //}
    }
}

