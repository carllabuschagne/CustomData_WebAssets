﻿using System;
namespace FlipZon.Models
{
    public class ThumbNailModel
    {
        public string Name { get; set; }
    }
}

