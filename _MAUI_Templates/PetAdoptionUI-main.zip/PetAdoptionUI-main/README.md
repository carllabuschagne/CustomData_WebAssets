 # Pet Adoption UI in .NET MAUI

<p>Pet Adoption UI is a replica made in .NET MAUI, hoping you enjoy it!</p>

<p align="center">
<img src="https://github.com/LeomarisReyes/PetAdoptionUI/blob/main/Images/AskXammy%20-%20AdoptionUI-FullUI.png" height="380" width="545" title="Contacts&MessageUI"/>
</p>

<hr />

## 📱  Supported platforms
<a target="_blank"><img src="https://img.shields.io/badge/-Android-%239fc137" height="41" width="100"></a>
<a target="_blank"><img src="https://img.shields.io/badge/-iOS-%23f8f8f8" height="41" width="100"></a>

<hr />

## 📒  Do you want to know how to do it?
<p> Enter to my article: <a href="https://askxammy.com" Target="_blank">https://askxammy.com/</a></p>
<p> Design obteined from Dribble:  <a href="https://dribbble.com/shots/9794301-Pet-Adoption-App" Target="_blank">https://dribbble.com/shots/9794301-Pet-Adoption-App</a></p>
