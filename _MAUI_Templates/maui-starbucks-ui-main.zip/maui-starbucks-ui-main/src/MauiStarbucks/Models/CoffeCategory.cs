﻿namespace MauiStarbucks.Models
{
    public enum CoffeCategory
    {
        All,
        Coffee,
        Tea,
        Drink,
        Food
    }
}
