﻿global using CommunityToolkit.Mvvm.ComponentModel;
global using MauiStarbucks.Models;
global using MauiStarbucks.ViewModels;
global using MauiStarbucks.Views.Pages;
global using MauiStarbucks.Services;
global using Splat;
global using CommunityToolkit.Mvvm.Input;
global using CommunityToolkit.Maui;
global using Microsoft.Maui.Platform;
global using System.Collections.ObjectModel;
global using System.Diagnostics;
global using System.Windows.Input;
global using MauiStarbucks.Views.ControlViews;


