namespace MauiStarbucks.Views.Pages;

public partial class WalletPage : CustomTabBar
{
	public WalletPage()
	{
		InitializeComponent();
	}
}