namespace MauiStarbucks.Views.Pages;

public partial class FavouritePage : CustomTabBar
{
	public FavouritePage()
	{
		InitializeComponent();
	}
}