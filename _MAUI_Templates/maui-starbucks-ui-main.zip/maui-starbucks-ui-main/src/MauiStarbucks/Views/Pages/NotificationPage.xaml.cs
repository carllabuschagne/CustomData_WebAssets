namespace MauiStarbucks.Views.Pages;

public partial class NotificationPage : CustomTabBar
{
	public NotificationPage()
	{
		InitializeComponent();
	}
}