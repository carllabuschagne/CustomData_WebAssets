# Medicine Tracker App - .NET MAUI UI Challenge

_(Medicine Tracker App created for UI Challenge made with .NET MAUI.)_

![Medicine Tracker App](UIMock/Images/mockup.jpg)

Based on this [design](https://dribbble.com/shots/19130423-Medicine-reminder-mobile-app) by [Al Nadir](https://dribbble.com/alnadir).
