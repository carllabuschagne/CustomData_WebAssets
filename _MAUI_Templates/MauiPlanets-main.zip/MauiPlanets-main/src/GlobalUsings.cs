﻿global using global::System;
global using global::System.Linq;
global using global::System.Threading.Tasks;
global using global::System.Collections.Generic;

global using global::Microsoft.Maui;
global using global::Microsoft.Maui.Controls;
global using global::Microsoft.Maui.Controls.Hosting;
global using global::Microsoft.Maui.Hosting;
global using global::Microsoft.Maui.Graphics;
global using global::Microsoft.Maui.LifecycleEvents;

global using MauiPlanets.Views;
global using MauiPlanets.Models;
global using MauiPlanets.Services;