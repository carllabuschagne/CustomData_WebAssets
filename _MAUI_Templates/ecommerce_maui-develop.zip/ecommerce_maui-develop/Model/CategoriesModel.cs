﻿
namespace EcommerceMAUI.Model
{
    public class CategoriesModel
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string Icon { get; set; }


    }
}
